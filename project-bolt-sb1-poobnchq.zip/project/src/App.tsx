import React, { useState } from 'react';
import { Heart, Activity, LineChart, AlertCircle, CheckCircle2, Loader2, Clipboard, Stethoscope, Pill as Pills, FileWarning as Running } from 'lucide-react';

interface FormData {
  age: number;
  gender: string;
  height: number;
  weight: number;
  systolic: number;
  diastolic: number;
  cholesterol: number;
  glucose: number;
  smoking: boolean;
  alcohol: boolean;
  active: boolean;
}

const initialFormData: FormData = {
  age: 30,
  gender: 'male',
  height: 170,
  weight: 70,
  systolic: 120,
  diastolic: 80,
  cholesterol: 200,
  glucose: 90,
  smoking: false,
  alcohol: false,
  active: true,
};

function calculateBMI(weight: number, height: number): number {
  return Number(((weight / (height * height)) * 10000).toFixed(1));
}

function getBMICategory(bmi: number): string {
  if (bmi < 18.5) return 'Underweight';
  if (bmi < 25) return 'Normal weight';
  if (bmi < 30) return 'Overweight';
  return 'Obese';
}

function getBPCategory(systolic: number, diastolic: number): string {
  if (systolic < 120 && diastolic < 80) return 'Normal';
  if (systolic < 130 && diastolic < 80) return 'Elevated';
  if (systolic < 140 || diastolic < 90) return 'Stage 1 Hypertension';
  return 'Stage 2 Hypertension';
}

function App() {
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [prediction, setPrediction] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate ML prediction
    await new Promise(resolve => setTimeout(resolve, 1500));
    setPrediction(Math.random() > 0.5 ? 'low' : 'high');
    setLoading(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    }));
  };

  const bmi = calculateBMI(formData.weight, formData.height);
  const bmiCategory = getBMICategory(bmi);
  const bpCategory = getBPCategory(formData.systolic, formData.diastolic);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <Heart className="w-8 h-8 text-red-500" />
            <h1 className="text-2xl font-bold text-gray-800">CardioDetect AI</h1>
          </div>
          <p className="mt-2 text-gray-600">Machine Learning-Based Cardiovascular Risk Assessment</p>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Form Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Activity className="text-blue-500" />
              Health Parameters
            </h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Age</label>
                  <input
                    type="number"
                    name="age"
                    value={formData.age}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Gender</label>
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  >
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Height (cm)</label>
                  <input
                    type="number"
                    name="height"
                    value={formData.height}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Weight (kg)</label>
                  <input
                    type="number"
                    name="weight"
                    value={formData.weight}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Systolic BP</label>
                  <input
                    type="number"
                    name="systolic"
                    value={formData.systolic}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Diastolic BP</label>
                  <input
                    type="number"
                    name="diastolic"
                    value={formData.diastolic}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Cholesterol (mg/dL)</label>
                  <input
                    type="number"
                    name="cholesterol"
                    value={formData.cholesterol}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Glucose (mg/dL)</label>
                  <input
                    type="number"
                    name="glucose"
                    value={formData.glucose}
                    onChange={handleInputChange}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    name="smoking"
                    checked={formData.smoking}
                    onChange={handleInputChange}
                    className="rounded text-blue-500 focus:ring-blue-500"
                  />
                  <span className="text-sm text-gray-700">Smoking</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    name="alcohol"
                    checked={formData.alcohol}
                    onChange={handleInputChange}
                    className="rounded text-blue-500 focus:ring-blue-500"
                  />
                  <span className="text-sm text-gray-700">Alcohol</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    name="active"
                    checked={formData.active}
                    onChange={handleInputChange}
                    className="rounded text-blue-500 focus:ring-blue-500"
                  />
                  <span className="text-sm text-gray-700">Active</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  'Generate Health Report'
                )}
              </button>
            </form>
          </div>

          {/* Results Section */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
              <Clipboard className="text-blue-500" />
              Health Assessment Report
            </h2>

            {!prediction && !loading && (
              <div className="text-center py-12">
                <Stethoscope className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Enter your health parameters and click "Generate Health Report" for a comprehensive assessment.</p>
              </div>
            )}

            {loading && (
              <div className="text-center py-12">
                <Loader2 className="w-16 h-16 text-blue-500 animate-spin mx-auto mb-4" />
                <p className="text-gray-500">Analyzing your health parameters...</p>
              </div>
            )}

            {prediction && (
              <div className="space-y-6">
                <div className={`p-4 rounded-lg ${prediction === 'low' ? 'bg-green-50' : 'bg-red-50'}`}>
                  <h3 className={`text-lg font-semibold mb-2 flex items-center gap-2 ${prediction === 'low' ? 'text-green-700' : 'text-red-700'}`}>
                    <Heart className="w-5 h-5" />
                    Cardiovascular Risk Assessment
                  </h3>
                  <p className={`${prediction === 'low' ? 'text-green-600' : 'text-red-600'}`}>
                    {prediction === 'low' ? 'Low Risk Profile' : 'High Risk Profile'}
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="border-b pb-4">
                    <h4 className="font-semibold text-gray-700 mb-2">Body Composition</h4>
                    <p className="text-gray-600">BMI: {bmi} kg/m² ({bmiCategory})</p>
                  </div>

                  <div className="border-b pb-4">
                    <h4 className="font-semibold text-gray-700 mb-2">Blood Pressure</h4>
                    <p className="text-gray-600">{formData.systolic}/{formData.diastolic} mmHg ({bpCategory})</p>
                  </div>

                  <div className="border-b pb-4">
                    <h4 className="font-semibold text-gray-700 mb-2">Metabolic Indicators</h4>
                    <p className="text-gray-600">
                      Cholesterol: {formData.cholesterol} mg/dL<br />
                      Glucose: {formData.glucose} mg/dL
                    </p>
                  </div>

                  <div className="border-b pb-4">
                    <h4 className="font-semibold text-gray-700 mb-2">Lifestyle Factors</h4>
                    <ul className="text-gray-600 space-y-1">
                      <li className="flex items-center gap-2">
                        <span className={formData.smoking ? 'text-red-500' : 'text-green-500'}>●</span>
                        Smoking: {formData.smoking ? 'Yes' : 'No'}
                      </li>
                      <li className="flex items-center gap-2">
                        <span className={formData.alcohol ? 'text-yellow-500' : 'text-green-500'}>●</span>
                        Alcohol Consumption: {formData.alcohol ? 'Yes' : 'No'}
                      </li>
                      <li className="flex items-center gap-2">
                        <span className={formData.active ? 'text-green-500' : 'text-red-500'}>●</span>
                        Physical Activity: {formData.active ? 'Active' : 'Sedentary'}
                      </li>
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-semibold text-gray-700 flex items-center gap-2">
                      <Pills className="w-5 h-5 text-blue-500" />
                      Recommendations
                    </h4>
                    <ul className="text-gray-600 space-y-2">
                      {bmi >= 25 && (
                        <li className="flex items-center gap-2">
                          <Running className="w-4 h-4 text-blue-500" />
                          Consider a weight management program
                        </li>
                      )}
                      {formData.systolic >= 130 || formData.diastolic >= 80 && (
                        <li className="flex items-center gap-2">
                          <Heart className="w-4 h-4 text-blue-500" />
                          Monitor blood pressure regularly
                        </li>
                      )}
                      {formData.smoking && (
                        <li className="flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 text-blue-500" />
                          Consider smoking cessation program
                        </li>
                      )}
                      {!formData.active && (
                        <li className="flex items-center gap-2">
                          <Running className="w-4 h-4 text-blue-500" />
                          Increase physical activity (aim for 150 minutes/week)
                        </li>
                      )}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-gray-600">
                <strong>Disclaimer:</strong> This report is generated based on machine learning analysis of provided parameters. It is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider.
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-gray-50 border-t mt-12">
        <div className="container mx-auto px-4 py-6">
          <p className="text-center text-gray-600 text-sm">
            © 2024 CardioDetect AI. This is a demonstration project and should not be used for actual medical diagnosis.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;